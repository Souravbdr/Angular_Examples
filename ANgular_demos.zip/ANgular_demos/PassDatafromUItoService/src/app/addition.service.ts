import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdditionService {

  constructor() { }

  plus(num1,num2)
  {
    return (parseInt(num1) + parseInt(num2));
  }

  minus(num1,num2)
  {
    return (parseInt(num1) - parseInt(num2));
  }

  multi(num1,num2)
  {
    return (parseInt(num1) * parseInt(num2));
  }

  divide(num1,num2)
  {
    return (parseInt(num1) / parseInt(num2));
  }
}
