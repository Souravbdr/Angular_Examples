import { Component } from '@angular/core';
import { AdditionService } from './addition.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ AdditionService ]
})
export class AppComponent {
  title = 'templateProj';
 
  num1:number;
  num2:number;
  result:number;

  constructor(private _service:AdditionService){
  }

  ngOnInit(){      
    
  }

  Calculate(){    
    this.result = this._service.plus(this.num1,this.num2);    
  }

  // minus(evt)
  // {
  //   this.result = this._service.minus(this.num1,this.num2);    
  // }

  minus()
  {
    this.result = this._service.minus(this.num1,this.num2);    
  }


  product(evt)
  {
    this.result = this._service.multi(this.num1,this.num2);    
  }

}
