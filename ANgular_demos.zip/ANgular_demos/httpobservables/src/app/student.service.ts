import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';  
import { IStudent } from './students';
import { Observable } from 'rxjs'; 

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  private url : string ='./assets/appData/students.json';  

  constructor(private http: HttpClient) { }  

  getStudents() : Observable<IStudent[]>
  {  
    return this.http.get<IStudent[]>(this.url);  
  }  
}
