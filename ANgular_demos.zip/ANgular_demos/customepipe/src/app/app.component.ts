import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  pageTitle:string="pipes in Angular";
  users:any[]=[
    {id:101,name:'kamal',city:'CHENNAI',salary:28765,dob:new Date("05/10/1989")},
    {id:102,name:'raj',city:'DELHI',salary:200,dob:new Date("06/10/1991")},
    {id:103,name:'Vimal',city:'MADURAI',salary:29834,dob:new Date("07/10/1987")},
  ];
}
