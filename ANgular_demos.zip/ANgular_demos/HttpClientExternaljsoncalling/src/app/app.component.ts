
import {UsersService} from './Services/users.service';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements  OnInit{
  pageTitle:string="pipes in Angular";
  users:any;

  constructor(private usersService:UsersService)
  {

  }
  ngOnInit()
  
    {
    this.usersService.getAllUsers().subscribe((data)=>{

      this.users=data;
    }); 
      
    } 
  }
