export interface book
{
    id:number;
    title:string;
    year:string;
    author:string;
}