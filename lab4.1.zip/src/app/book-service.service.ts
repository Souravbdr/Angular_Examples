import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { book } from './book';

@Injectable({
  providedIn: 'root'
})
export class BookServiceService {

  private url : string = './assets/booklist.json';

  constructor(private http:HttpClient) { }

  getBooks() : Observable<book[]>
  {
    return this.http.get<book[]>(this.url);
  }
}
