import { Component } from '@angular/core';
import { BookServiceService } from './book-service.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'lab4prob1';
  public book = [];
  constructor(private bookServ : BookServiceService){}
  ngOnInit()
  {
    this.bookServ.getBooks().subscribe(data => this.book= data);
  }
}
