import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
  name: 'filterTitle'
})
export class FilterTitlePipe implements PipeTransform {

  transform(books:any, find:any): any {
    if(find==undefined) return books;
    return books.filter(function(book:any){
        
        return book.title.toLowerCase().includes(find.toLowerCase());
    })
 }

}
