import { Component } from '@angular/core';
import { BookService } from './book.service'
import {FormGroup,FormBuilder,ReactiveFormsModule} from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'lab4prob2';


  public books= [];
  constructor(private bookServ:BookService,private fb:FormBuilder){}
  ngOnInit(){
    this.bookServ.getBooks().subscribe((data)=> this.books=data);
  }
  
  
  pipe= this.fb.group({
    tit:['']
  });
  
  str:string;
  onsel(e)
  {
    this.str=e.target.value;
  }
}
