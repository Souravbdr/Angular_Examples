import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterYear'
})
export class FilterYearPipe implements PipeTransform {

  transform(book: any, find: any): any {
    if(find==""||find==undefined) return book;
    return book.filter(function(book:any)
  {
    return book.year==find;
  });
  }

}
