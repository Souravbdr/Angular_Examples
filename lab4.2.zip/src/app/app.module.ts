import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FilterTitlePipe } from './filter-title.pipe';
import { FilterAuthorPipe } from './filter-author.pipe';
import { FilterYearPipe } from './filter-year.pipe';
import { HttpClientModule } from '@angular/common/http';
import { BookService } from './book.service';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    FilterTitlePipe,
    FilterAuthorPipe,
    FilterYearPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,ReactiveFormsModule
  ],
  providers: [BookService],
  bootstrap: [AppComponent]
})
export class AppModule { }
