import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterAuthor'
})
export class FilterAuthorPipe implements PipeTransform {

  transform(book: any, find: any): any {
    if(find==undefined) return book;
    return book.filter(function(book:any)
  {
    return book.author.toLowerCase().includes(find.toLowerCase());
  });
  }

}
