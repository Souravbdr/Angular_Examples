export interface Book{
    id:number;
    title:string;
    year:number;
    auther:string;
    
}